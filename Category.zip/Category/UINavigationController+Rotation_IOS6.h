//
//  UINavigationController+Rotation_IOS6.h
//  iPathologist
//
//  Created by Ren XinWei on 13-6-8.
//  Copyright (c) 2013年 Motic China Group Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (Rotation_IOS6)

@end
