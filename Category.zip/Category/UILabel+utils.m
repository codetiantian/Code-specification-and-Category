//
//  UILabel+utils.m
//  Btn_HQHD_2.0
//
//  Created by MacPro-Mr.Lu on 14-3-20.
//  Copyright (c) 2014年 XMGD_Mr.Lu. All rights reserved.
//

#import "UILabel+utils.h"

#define L_SYSTEM_VERSION_MORE_THAN(x) ([[UIDevice currentDevice].systemVersion floatValue] >= x) //IOS版本适配
#define L_SYSTEM_VERSION_LESS_THAN(x) ([[UIDevice currentDevice].systemVersion floatValue] < x) //IOS版本适配

@implementation UILabel (utils)

- (float)labelLength
{
    float width = 0.0;
    CGSize labsize = CGSizeZero;
    UIFont *font = self.font;
    NSString *strString = self.text;
    if (L_SYSTEM_VERSION_LESS_THAN(7.0)) {
        labsize = [strString sizeWithFont:font constrainedToSize:CGSizeMake(MAXFLOAT, self.frame.size.height) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
        paragraphStyle.lineBreakMode = self.lineBreakMode;

        labsize = [strString boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil] context:nil].size;
    }
    
    width = labsize.width;
    return ceil(width);
}

- (float)labelHeight
{
    float Height = 0.0;
    CGSize labsize = CGSizeZero;
    UIFont *font = self.font;
    NSString *strString = self.text;
    
    if (L_SYSTEM_VERSION_LESS_THAN(7.0)) {
        labsize = [strString sizeWithFont:font constrainedToSize:CGSizeMake(self.frame.size.width,MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
//        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
//        paragraphStyle.lineBreakMode = self.lineBreakMode;
        
        labsize = [strString boundingRectWithSize:CGSizeMake(self.frame.size.width,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName,nil] context:nil].size;
    }
    Height = labsize.height;
    Height = Height +1;
    return ceil(Height);
}

- (float )labelLength:(NSString *)strString{
    float width = 0.0;
    CGSize labsize = CGSizeZero;
    UIFont *font = self.font;
    if (L_SYSTEM_VERSION_LESS_THAN(7.0)) {
        labsize = [strString sizeWithFont:font constrainedToSize:CGSizeMake(MAXFLOAT, self.frame.size.height) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
        labsize = [strString boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil] context:nil].size;
    }
    
    width = labsize.width;
    return width;
}

- (float )labelLength:(NSString *)strString withFont:(UIFont *)font{
    float width = 0.0;
    CGSize labsize = CGSizeZero;
    if (L_SYSTEM_VERSION_LESS_THAN(7.0)) {
        labsize = [strString sizeWithFont:font constrainedToSize:CGSizeMake(MAXFLOAT, self.frame.size.height) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
        labsize = [strString boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil] context:nil].size;
    }
    
    width = labsize.width;
    return width;
}

- (float)labelheight:(NSString *)strString withFont:(UIFont *)font
{
    float height = 0.0;
    CGSize labsize = CGSizeZero;
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = self.lineBreakMode;
    if (L_SYSTEM_VERSION_LESS_THAN(7.0)) {
        labsize = [strString sizeWithFont:font constrainedToSize:CGSizeMake(self.frame.size.width, MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
        labsize = [strString boundingRectWithSize:CGSizeMake(self.frame.size.width,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName,paragraphStyle,NSParagraphStyleAttributeName, nil] context:nil].size;
    }
    height = labsize.height+1;
    return ceil(height);
}

-(void)alignTop {
    CGSize fontSize =[self.text sizeWithFont:self.font];
    double finalHeight = fontSize.height *self.numberOfLines;
    double finalWidth =self.frame.size.width;//expected width of label
    CGSize theStringSize =[self.text sizeWithFont:self.font constrainedToSize:CGSizeMake(finalWidth, finalHeight) lineBreakMode:self.lineBreakMode];
    int newLinesToPad =(finalHeight - theStringSize.height)/ fontSize.height;
    for(int i=0; i<newLinesToPad; i++)
        self.text =[self.text stringByAppendingString:@"\n "];
}

-(void)alignBottom {
    CGSize fontSize =[self.text sizeWithFont:self.font];
    double finalHeight = fontSize.height *self.numberOfLines;
    double finalWidth =self.frame.size.width;//expected width of label
    CGSize theStringSize =[self.text sizeWithFont:self.font constrainedToSize:CGSizeMake(finalWidth, finalHeight) lineBreakMode:self.lineBreakMode];
    int newLinesToPad =(finalHeight - theStringSize.height)/ fontSize.height;
    for(int i=0; i<newLinesToPad; i++)
        self.text =[NSString stringWithFormat:@" \n%@",self.text];
}

@end
