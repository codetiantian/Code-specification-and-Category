//
//  UIImageView+LazyLoad.h
//  BJEducation_student
//
//  Created by Mac_ZL on 15/4/13.
//  Copyright (c) 2015年 Baijiahulian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (LazyLoad)

- (void)setLazyLoadURL:(NSString *) url isVisible:(BOOL) isVisible placeholderImage:(NSString *) imageName animateBlock:(void(^)(void))animteBlock;

- (void)setLazyLoadURL:(NSString *) url isVisible:(BOOL) isVisible placeholderImage:(NSString *) imageName;

- (void)setLazyLoadURL:(NSString *) url placeholderImage:(NSString *) imageName;

@end
