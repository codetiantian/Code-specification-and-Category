//
//  NSURLRequest+utils.h
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14/12/8.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURLRequest (utils)

+ (void)saveHttpDefaultUser_Agent;
- (void)setHttpMLUser_Agent:(NSString *)user_agent;
- (void)setHttpMLCookie:(NSHTTPCookie *)cookie;

@end
