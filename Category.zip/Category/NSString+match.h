//
//  NSString+match.h
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-9-15.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (match)

/**
 *  手机号验证
 *
 *  @param mobileNum 手机号
 *
 *  @return 是否为正确的手机号
 */
+ (BOOL)isValidateMobile:(NSString *)mobileNum;

- (BOOL)isValidMobile;

/**
 *  邮箱验证
 *
 *  @param email 邮箱
 *
 *  @return 是否为正确的邮箱
 */
+ (BOOL)isValidateEmail:(NSString *)email;

- (BOOL)isValidEmail;

@end
