//
//  NSString+utils.m
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-9-7.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import "NSString+utils.h"

@implementation NSString (utils)

+(NSString *)getStrByNil:(NSString *)str{
    if (str==nil||[str isKindOfClass:[NSNull class]]) {
        return @"";
    }
    return str;
}

- (CGFloat)stringLengthWithFont:(UIFont *)font{
    CGFloat width = 0.0;
    CGSize labsize = CGSizeZero;
    if ([[UIDevice currentDevice].systemVersion floatValue] < 7.0) {
        labsize = [self sizeWithFont:font constrainedToSize:CGSizeMake(MAXFLOAT, font.pointSize) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
        labsize = [self boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, font.pointSize) options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil] context:nil].size;
    }
    
    width = labsize.width;
    return  ceilf(width);
}

- (CGFloat )stringHeightWithFont:(UIFont *)font size:(CGSize)size{
    CGFloat height = 0.0;
    CGSize labsize = CGSizeZero;
    if ([[UIDevice currentDevice].systemVersion floatValue] < 7.0) {
        labsize = [self sizeWithFont:font constrainedToSize:CGSizeMake(size.width, MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
    {
        labsize = [self boundingRectWithSize:CGSizeMake(size.width, MAXFLOAT) options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil] context:nil].size;
    }
    
    height = labsize.height;
    height = height + 1;
    return ceilf(height);
}

- (BOOL)isUrl
{
    NSString *match=@"((http|ftp|https)://)(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\\&%_\\./-~-]*)?";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF matches %@", match];
    return [predicate evaluateWithObject:self];
    return YES;
}

+ (NSString *)encodeToPercentEscapeString: (NSString *) input
{
    // Encode all the reserved characters, per RFC 3986
    // (<http://www.ietf.org/rfc/rfc3986.txt>)
    NSString*
    outputStr = (__bridge NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                             
                                                                             NULL, /* allocator */
                                                                             
                                                                             (__bridge CFStringRef)input,
                                                                             
                                                                             NULL, /* charactersToLeaveUnescaped */
                                                                             
                                                                             (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                             
                                                                             kCFStringEncodingUTF8);
    return outputStr;
}

+ (NSString *)decodeFromPercentEscapeString: (NSString *) input
{
    NSMutableString *outputStr = [NSMutableString stringWithString:input];
    [outputStr replaceOccurrencesOfString:@"+"
                               withString:@" "
                                  options:NSLiteralSearch
                                    range:NSMakeRange(0, [outputStr length])];
    
    return [outputStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

@end
