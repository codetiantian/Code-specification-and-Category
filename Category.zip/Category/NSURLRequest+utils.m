//
//  NSURLRequest+utils.m
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14/12/8.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import "NSURLRequest+utils.h"

@implementation NSURLRequest (utils)

+ (void)saveHttpDefaultUser_Agent
{
    UIWebView* webView = [[UIWebView alloc] initWithFrame:CGRectZero];
    NSString* default_user_agent = [webView stringByEvaluatingJavaScriptFromString:@"navigator.userAgent"];
    [[NSUserDefaults standardUserDefaults] setValue:default_user_agent forKey:@"bj_user_agent"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)setHttpMLUser_Agent:(NSString *)user_agent
{
    NSString* default_user_agent = [[NSUserDefaults standardUserDefaults] valueForKey:@"bj_user_agent"];
    user_agent = [NSString stringWithFormat:@"%@ %@",default_user_agent,user_agent];
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{@"UserAgent":user_agent}];
}

- (void)setHttpMLCookie:(NSHTTPCookie *)cookie
{
    DLog(@"cookie:%@",cookie.description);
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
}

@end
