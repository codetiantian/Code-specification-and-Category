//
//  NSString+MD5.h
//  MotherBaby
//
//  Created by Mac_ZL on 14-7-8.
//  Copyright (c) 2014年 YuanFan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(MD5)
-(NSString *)md5;
@end
