//
//  UIView+Debug.h
//  Pray
//
//  Created by Tapan Thaker on 29/08/14.
//  Copyright (c) 2014 Tapan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DebugFrameView.h"

@interface UIView (Debug)
@property (nonatomic, strong) DebugFrameView *debugFrameView;

@end
