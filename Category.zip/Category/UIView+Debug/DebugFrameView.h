//
//  DebugFrameView.h
//  DebugView
//
//  Created by Tapan Thaker on 02/10/14.
//  Copyright (c) 2014 Tapan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DebugFrameView : UIView

@property(nonatomic,strong)NSMutableArray *views;

@end
