//
//  NSString+utils.h
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-9-7.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (utils)

+(NSString *)getStrByNil:(NSString *)str;
//返回长度
- (CGFloat )stringLengthWithFont:(UIFont *)font;
- (CGFloat )stringHeightWithFont:(UIFont *)font size:(CGSize)size;

- (BOOL)isUrl;

+ (NSString *)encodeToPercentEscapeString: (NSString *) input;

+ (NSString *)decodeFromPercentEscapeString: (NSString *) input;

@end
