//
//  NSDictionary+EaseMobMessageExt.h
//  BJEducation
//
//  Created by archer on 9/13/14.
//  Copyright (c) 2014 com.bjhl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (EaseMobMessageExt)

- (NSString *)em_title;
- (NSString *)em_url;
- (NSDate *)em_date;

@end
