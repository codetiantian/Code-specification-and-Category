//
//  UIImage+utils.h
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-9-3.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (utils)

+ (UIImage *)buttonImageFromColor:(UIColor *)color withFrame:(CGRect)frame;
- (UIImage *) renderAtSize:(const CGSize) size;
- (UIImage *) maskWithImage:(const UIImage *) maskImage;
- (UIImage *) maskWithColor:(UIColor *) color;
@end
