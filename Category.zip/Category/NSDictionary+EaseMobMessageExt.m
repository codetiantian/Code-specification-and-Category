//
//  NSDictionary+EaseMobMessageExt.m
//  BJEducation
//
//  Created by archer on 9/13/14.
//  Copyright (c) 2014 com.bjhl. All rights reserved.
//

#import "NSDictionary+EaseMobMessageExt.h"

@implementation NSDictionary (EaseMobMessageExt)


- (NSString *)em_title{
    if ([self objectForKey:@"message"] && [[self objectForKey:@"message"] objectForKey:@"type"]){
        return [[self objectForKey:@"message"] objectForKey:@"type"];
    }
    return nil;
}

- (NSString *)em_url{
    if ([self objectForKey:@"message"] && [[self objectForKey:@"message"] objectForKey:@"url"]){
        return [[self objectForKey:@"message"] objectForKey:@"url"];
    }
    return nil;
}

- (NSDate *)em_date{
    if ([self objectForKey:@"message"] && [[self objectForKey:@"message"] objectForKey:@"create_time"]){
        NSString *dateStr = [[self objectForKey:@"message"] objectForKey:@"create_time"];
        
        if (dateStr){
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            return [formatter dateFromString:dateStr];
        }
    }
    
    return nil;
}

@end
