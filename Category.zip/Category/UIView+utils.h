//
//  UIView+utils.h
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-9-19.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (utils)
+(UIImage *)captureView:(UIView *)theView;
@end
