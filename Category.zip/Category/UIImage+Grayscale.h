//
//  UIImage+Grayscale.h
//  BJEducation
//
//  Created by archer on 9/17/14.
//  Copyright (c) 2014 com.bjhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Grayscale)

/**
 *  将图片变为灰色
 */
- (UIImage *)convertToGrayscale;

@end
