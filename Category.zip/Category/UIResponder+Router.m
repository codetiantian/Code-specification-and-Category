//
//  UIResponder+Router.m
//  BJEducation_student
//
//  Created by Mac_ZL on 14-8-29.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import "UIResponder+Router.h"

@implementation UIResponder(Router)
- (void)routerEventWithName:(NSString *)eventName userInfo:(id)userInfo
{
    [[self nextResponder] routerEventWithName:eventName userInfo:userInfo];
}
@end
