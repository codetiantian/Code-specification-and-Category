//
//  UIView+utils.m
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-9-19.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import "UIView+utils.h"

@implementation UIView (utils)
+(UIImage*)captureView:(UIView *)theView
{
    CGRect rect = theView.frame;
    //支持retina高分的关键
    if(UIGraphicsBeginImageContextWithOptions != NULL)
    {
        UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0.0);
    } else {
        UIGraphicsBeginImageContext(rect.size);
    }
    CGContextRef context =UIGraphicsGetCurrentContext();
    [theView.layer renderInContext:context];
    UIImage *img =UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}
@end
