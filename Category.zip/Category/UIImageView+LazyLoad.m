//
//  UIImageView+LazyLoad.m
//  BJEducation_student
//
//  Created by Mac_ZL on 15/4/13.
//  Copyright (c) 2015年 Baijiahulian. All rights reserved.
//

#import "UIImageView+LazyLoad.h"
#import "UIImageView+WebCache.h"
@implementation UIImageView (LazyLoad)

- (void)setLazyLoadURL:(NSString *) url placeholderImage:(NSString *) imageName
{
    __WeakSelf__ wSelf = self;
    [self setLazyLoadURL:url isVisible:YES placeholderImage:imageName animateBlock:^{
        
        [UIView animateWithDuration:.25 animations:^{
            wSelf.alpha = 1.0;
        }];
    }];
}

- (void)setLazyLoadURL:(NSString *) url isVisible:(BOOL) isVisible placeholderImage:(NSString *) imageName
{
    __WeakSelf__ wSelf = self;
    [self setLazyLoadURL:url isVisible:isVisible placeholderImage:imageName animateBlock:^{
        
        [UIView animateWithDuration:.25 animations:^{
            wSelf.alpha = 1.0;
        }];
    }];
}

- (void)setLazyLoadURL:(NSString *) url isVisible:(BOOL) isVisible placeholderImage:(NSString *) imageName animateBlock:(void(^)(void))animteBlock
{
    NSURL *targetURL = [NSURL URLWithString:url];
    
    if (![[self sd_imageURL] isEqual:targetURL])
    {
        self.alpha = 0.0;
        SDWebImageManager *manager = [SDWebImageManager sharedManager];
        BOOL shouldLoadImage = YES;
        if (!isVisible) {
            SDImageCache *cache = [manager imageCache];
            NSString *key = [manager cacheKeyForURL:targetURL];
            if (![cache imageFromMemoryCacheForKey:key]) {
                shouldLoadImage = NO;
            }
        }
        if (shouldLoadImage) {
            [self sd_setImageWithURL:targetURL placeholderImage:[UIImage imageNamed:imageName] options:SDWebImageHandleCookies completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                if (!error && [imageURL isEqual:targetURL]) {
//                    // fade in animation
//                    [UIView animateWithDuration:.25 animations:^{
//                        self.alpha = 1.0;
//                    }];
                    animteBlock();
                }
            }];
        }
    }

}
@end
