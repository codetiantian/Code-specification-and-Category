//
//  UITableViewCell+utils.h
//  BJEducation_student
//
//  Created by Mrlu-bjhl on 14-10-17.
//  Copyright (c) 2014年 Baijiahulian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (utils)

@end
